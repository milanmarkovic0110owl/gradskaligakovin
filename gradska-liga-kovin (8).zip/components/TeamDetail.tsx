
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Team, PlayerStats, TeamMatch } from '../types';
import { Trophy, Users, Calendar, ArrowRight, User } from 'lucide-react';

interface TeamDetailProps {
  teams: Team[];
  players: PlayerStats[];
  matches: TeamMatch[];
}

const TeamDetail: React.FC<TeamDetailProps> = ({ teams, players, matches }) => {
  const { teamId } = useParams<{ teamId: string }>();
  const team = teams.find(t => t.id === decodeURIComponent(teamId || ''));
  
  if (!team) return <div className="p-4 text-white font-black uppercase tracking-widest text-[10px]">Ekipa nije pronađena.</div>;

  const teamPlayers = players.filter(p => p.teamId === team.id);
  const teamMatches = matches.filter(m => m.homeTeamId === team.id || m.awayTeamId === team.id);
  const standingsRank = [...teams].sort((a, b) => b.points - a.points).findIndex(t => t.id === team.id) + 1;

  return (
    <div className="space-y-4">
      {/* Header Section */}
      <div className="bg-[#0d1117] p-4 md:p-12 border-4 border-[#010409] flex flex-row items-center gap-4 md:gap-10 sharp-border">
        <div className="bg-[#010409] text-[#00d4ff] w-16 h-16 md:w-32 md:h-32 flex items-center justify-center font-black text-3xl md:text-7xl sharp-border shrink-0 italic border-2 border-[#161b22]">
          {team.name.charAt(0)}
        </div>
        <div className="min-w-0">
          <h2 className="text-xl md:text-6xl font-black italic uppercase tracking-tighter text-white truncate leading-none mb-2">{team.name}</h2>
          <div className="flex gap-2">
            <span className="bg-[#161b22] px-3 py-1 border border-[#30363d] text-[#00d4ff] font-black uppercase text-[8px] md:text-xs tracking-widest italic">POZICIJA #{standingsRank}</span>
            <span className="bg-[#161b22] px-3 py-1 border border-[#30363d] text-white font-black uppercase text-[8px] md:text-xs tracking-widest italic">{team.points} BOD</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Stats & Players */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-[#0d1117] p-4 border-4 border-[#010409] sharp-border">
             <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] mb-4 flex items-center gap-2 italic">
               <Users size={14} /> SASTAV EKIPE
             </h3>
             <div className="space-y-2">
                {teamPlayers.map(p => (
                  <div key={p.id} className="bg-[#010409] border-2 border-[#161b22] p-2 flex items-center justify-between group hover:bg-[#161b22] transition-colors">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-[#0d1117] border border-[#161b22] flex items-center justify-center">
                        <User size={12} className="text-[#484f58]" />
                      </div>
                      <span className="text-[10px] md:text-xs font-black uppercase text-white tracking-widest truncate">{p.name}</span>
                    </div>
                    <span className="text-[8px] font-black text-[#00d4ff] italic">{p.matchesWon}:{p.matchesLost}</span>
                  </div>
                ))}
             </div>
          </div>

          <div className="bg-[#0d1117] p-4 border-4 border-[#010409] sharp-border">
             <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] mb-4 flex items-center gap-2 italic">
               <Trophy size={14} /> UČINAK
             </h3>
             <div className="grid grid-cols-2 gap-2">
                <MiniStat label="Pobede" value={team.won} />
                <MiniStat label="Porazi" value={team.lost} />
                <MiniStat label="Partije (+)" value={team.matchesWon} />
                <MiniStat label="Partije (-)" value={team.matchesLost} />
             </div>
          </div>
        </div>

        {/* Right Column: Match History */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#0d1117] border-4 border-[#010409] sharp-border">
             <div className="bg-[#010409] p-4 border-b-2 border-[#161b22] flex items-center justify-between">
                <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] italic flex items-center gap-2">
                  <Calendar size={14} /> ISTORIJA MEČEVA
                </h3>
             </div>
             <div className="divide-y-2 divide-[#010409]">
                {teamMatches.map(m => (
                  <div key={m.id} className="p-3 md:p-6 flex items-center justify-between hover:bg-[#161b22] transition-all">
                    <div className="flex flex-col gap-1">
                      <span className="text-[7px] md:text-[9px] font-black text-[#484f58] uppercase tracking-widest">KOLO {m.round} / {m.date}</span>
                      <div className="flex items-center gap-3">
                         <span className={`text-[10px] md:text-sm font-black uppercase italic ${m.homeTeamId === team.id ? 'text-[#00d4ff]' : 'text-white'}`}>{m.homeTeamId}</span>
                         <span className="text-[8px] font-black text-[#484f58]">VS</span>
                         <span className={`text-[10px] md:text-sm font-black uppercase italic ${m.awayTeamId === team.id ? 'text-[#00d4ff]' : 'text-white'}`}>{m.awayTeamId}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      {m.isCompleted ? (
                        <div className="text-[12px] md:text-2xl font-[900] italic text-white bg-[#010409] px-3 py-1 border border-[#161b22] shadow-sm">
                          {m.scoreHome} : {m.scoreAway}
                        </div>
                      ) : (
                        <span className="text-[7px] md:text-[9px] font-black text-[#00d4ff] uppercase tracking-widest italic opacity-40">NA ČEKANJU</span>
                      )}
                    </div>
                  </div>
                ))}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const MiniStat: React.FC<{ label: string, value: number }> = ({ label, value }) => (
  <div className="bg-[#010409] p-2 border border-[#161b22] sharp-border">
    <span className="text-[7px] font-black text-[#484f58] uppercase block mb-1">{label}</span>
    <span className="text-sm font-black italic text-white">{value}</span>
  </div>
);

export default TeamDetail;
