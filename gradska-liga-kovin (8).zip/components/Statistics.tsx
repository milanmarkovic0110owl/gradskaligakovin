
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
// Added missing import for BarChart3
import { BarChart3 } from 'lucide-react';
import { TeamMatch, PlayerStats } from '../types';

interface StatisticsProps {
  matches: TeamMatch[];
  players: PlayerStats[];
}

const Statistics: React.FC<StatisticsProps> = ({ matches, players }) => {
  const topPlayers = [...players].sort((a, b) => b.matchesWon - a.matchesWon || b.setsWon - a.setsWon).slice(0, 10);
  
  const chartData = topPlayers.slice(0, 5).map(p => ({
    name: p.name.split(' ')[0],
    pobede: p.matchesWon,
    porazi: p.matchesLost
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="bg-[#0d1117] border-4 border-[#010409] p-4 md:p-8 sharp-border">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-1.5 h-6 bg-[#00d4ff]"></div>
            <h3 className="text-[10px] md:text-sm font-black uppercase tracking-widest text-[#00d4ff] italic">Top 5 Igrača (Pobede/Porazi)</h3>
          </div>
          <div className="h-[250px] md:h-[450px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#30363d" />
                <XAxis dataKey="name" fontSize={10} fontWeight="900" axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} />
                <YAxis fontSize={10} fontWeight="900" axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} />
                <Tooltip 
                  cursor={{fill: '#161b22'}}
                  contentStyle={{backgroundColor: '#010409', border: '2px solid #30363d', borderRadius: '0', fontSize: '12px', fontWeight: '900', color: '#fff'}} 
                />
                <Bar dataKey="pobede" fill="#00d4ff" radius={[2, 2, 0, 0]} />
                <Bar dataKey="porazi" fill="#ef4444" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="bg-[#0d1117] border-4 border-[#010409] sharp-border flex flex-col">
          <div className="bg-[#010409] p-4 border-b-2 border-[#161b22]"><h3 className="text-[10px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] italic">Lideri Sezone</h3></div>
          <div className="divide-y-2 divide-[#010409] overflow-y-auto max-h-[350px] md:max-h-[495px] scrollbar-hide">
             {topPlayers.map((p, idx) => (
               <div key={p.id} className="p-4 flex items-center justify-between hover:bg-[#161b22] transition-all group">
                 <div className="flex items-center gap-4">
                   <div className="font-black text-xl md:text-3xl text-white/30 italic group-hover:text-[#00d4ff] transition-colors">{idx + 1}</div>
                   <div>
                     <div className="font-black text-[10px] md:text-sm uppercase text-white tracking-widest italic group-hover:text-[#00d4ff]">{p.name}</div>
                     <div className="text-[8px] text-[#9ca3af] font-black uppercase tracking-widest group-hover:text-[#00d4ff]/60">{p.teamId}</div>
                   </div>
                 </div>
                 <div className="flex gap-6">
                   <div className="text-right">
                     <div className="text-[12px] md:text-lg font-black text-white">{p.matchesWon}</div>
                     <div className="text-[7px] text-[#9ca3af] uppercase font-black">Pob</div>
                   </div>
                   <div className="text-right">
                     <div className="text-[12px] md:text-lg font-black text-[#00d4ff] italic">{p.setsWon}</div>
                     <div className="text-[7px] text-[#9ca3af] uppercase font-black">Set</div>
                   </div>
                 </div>
               </div>
             ))}
          </div>
        </section>
      </div>

      <div className="bg-[#010409] p-8 md:p-24 text-center border-4 border-[#0d1117] sharp-border relative overflow-hidden">
         <h2 className="text-2xl md:text-7xl font-black italic uppercase text-white relative z-10 leading-none tracking-tighter">ANALITIKA 2025</h2>
         <p className="max-w-xl mx-auto text-[8px] md:text-[12px] font-black uppercase tracking-[0.4em] text-[#00d4ff] mt-4 relative z-10 opacity-80">PROFI SISTEM ZA PRAĆENJE UČINKA</p>
         <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
            {/* Fix for line 77: Ensure BarChart3 is imported from lucide-react */}
            <BarChart3 size={400} />
         </div>
      </div>
    </div>
  );
};

export default Statistics;
