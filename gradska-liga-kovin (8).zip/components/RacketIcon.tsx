// This file is no longer used and can be removed.
export const RacketIcon = () => null;
export const TableSilhouette = () => null;
