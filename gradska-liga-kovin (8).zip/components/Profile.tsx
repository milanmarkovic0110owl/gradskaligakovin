
import React, { useState } from 'react';
import { User, PlayerStats } from '../types';
import { UserCircle, Save, Key, Trophy, Award, BarChart } from 'lucide-react';

interface ProfileProps {
  user: User;
  players: PlayerStats[];
  onUpdatePassword: (playerId: string, newPass: string) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, players, onUpdatePassword }) => {
  const player = players.find(p => p.id === user.playerId);
  const [newPassword, setNewPassword] = useState('');
  const [msg, setMsg] = useState('');

  if (!player) return <div className="p-4 text-white font-black uppercase tracking-widest text-[10px]">Igrač nije pronađen.</div>;

  const handleUpdatePass = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 4) {
      setMsg('Lozinka mora imati bar 4 karaktera.');
      return;
    }
    onUpdatePassword(player.id, newPassword);
    setMsg('Lozinka uspešno promenjena!');
    setNewPassword('');
  };

  return (
    <div className="space-y-4">
      <div className="bg-[#0d1117] p-4 md:p-12 border-4 border-[#010409] flex flex-row items-center gap-4 md:gap-10">
        <div className="w-16 h-16 md:w-32 md:h-32 bg-[#010409] border-2 border-[#161b22] flex items-center justify-center sharp-border relative overflow-hidden shrink-0">
           {player.imageUrl ? (
             <img src={player.imageUrl} alt={player.name} className="w-full h-full object-cover" />
           ) : (
             <UserCircle size={40} className="text-[#161b22]" />
           )}
        </div>
        <div className="min-w-0">
          <h2 className="text-xl md:text-5xl font-black italic uppercase tracking-tighter text-white truncate leading-none mb-2">{player.name}</h2>
          <span className="bg-[#161b22] px-3 py-1 border border-[#30363d] text-[#00d4ff] font-black uppercase text-[8px] md:text-xs tracking-widest italic">{player.teamId}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#0d1117] p-4 border-4 border-[#010409] sharp-border">
             <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] mb-4 flex items-center gap-2">
               <Trophy size={14} /> STATISTIKA
             </h3>
             <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <StatCard label="Pobede" value={player.matchesWon} />
                <StatCard label="Porazi" value={player.matchesLost} />
                <StatCard label="Setovi (+)" value={player.setsWon} />
                <StatCard label="Učinak" value={`${player.matchesPlayed > 0 ? Math.round((player.matchesWon/player.matchesPlayed)*100) : 0}%`} />
             </div>
          </div>

          <div className="bg-[#0d1117] p-4 border-4 border-[#010409] sharp-border">
             <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] mb-4">ANATALIKA POENA</h3>
             <div className="space-y-3">
                <ProgressBar label="Dobijeni" val={player.pointsWon} max={player.pointsWon + player.pointsLost} color="bg-[#00d4ff]" />
                <ProgressBar label="Izgubljeni" val={player.pointsLost} max={player.pointsWon + player.pointsLost} color="bg-red-700" />
             </div>
          </div>
        </div>

        <div className="bg-[#0d1117] p-4 border-4 border-[#010409] sharp-border h-fit">
           <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] mb-4 flex items-center gap-2">
             <Key size={14} /> SIGURNOST
           </h3>
           <form onSubmit={handleUpdatePass} className="space-y-4">
              <input 
                type="password" 
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full bg-[#010409] border-2 border-[#161b22] px-4 py-3 text-white font-black italic outline-none focus:border-[#00d4ff] transition-all sharp-border text-[10px]"
                placeholder="Nova lozinka..."
              />
              <button type="submit" className="w-full bg-white text-[#010409] py-3 font-black uppercase tracking-widest text-[9px] hover:bg-[#00d4ff] transition-all sharp-border flex items-center justify-center gap-2">
                <Save size={14} /> SAČUVAJ
              </button>
              {msg && <p className={`text-[8px] font-black uppercase tracking-widest text-center ${msg.includes('uspešno') ? 'text-green-500' : 'text-red-500'}`}>{msg}</p>}
           </form>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ label: string, value: string | number }> = ({ label, value }) => (
  <div className="bg-[#010409] p-3 border-2 border-[#161b22] sharp-border flex flex-col justify-center">
    <span className="text-[7px] font-black text-[#484f58] uppercase tracking-widest mb-1 truncate">{label}</span>
    <span className="text-sm md:text-xl font-black italic text-white leading-none">{value}</span>
  </div>
);

const ProgressBar: React.FC<{ label: string, val: number, max: number, color: string }> = ({ label, val, max, color }) => (
  <div>
    <div className="flex justify-between mb-1">
      <span className="text-[8px] font-black text-white uppercase">{label}</span>
      <span className="text-[10px] font-black text-white/50">{val}</span>
    </div>
    <div className="h-2 bg-[#010409] border border-[#161b22]">
      <div className={`h-full ${color}`} style={{ width: `${Math.min(100, (val / (max || 1)) * 100)}%` }}></div>
    </div>
  </div>
);

export default Profile;
