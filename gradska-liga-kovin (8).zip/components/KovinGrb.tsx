
import React from 'react';

interface KovinGrbProps {
  className?: string;
  opacity?: number;
  grayscale?: boolean;
}

const KovinGrb: React.FC<KovinGrbProps> = ({ className, opacity = 1, grayscale = false }) => {
  // Precizne boje preuzete direktno sa slike
  const skyColor = grayscale ? "currentColor" : "#ACE5EE";
  const wallColor = grayscale ? "currentColor" : "#E36C2C";
  const warriorColor = grayscale ? "currentColor" : "#FFFFFF";
  const gateColor = grayscale ? "currentColor" : "#6BB64A";
  const waterBase = grayscale ? "currentColor" : "#6BB64A";
  const waterWave = grayscale ? "currentColor" : "#2E3192";
  const textColor = grayscale ? "currentColor" : "#002E5D";
  const strokeColor = grayscale ? "currentColor" : "#002E5D";

  return (
    <svg 
      viewBox="0 0 400 400" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
      style={{ opacity }}
    >
      {/* Background Circle */}
      {!grayscale && <circle cx="200" cy="200" r="198" fill="white" />}
      
      {/* Double Border */}
      <circle cx="200" cy="200" r="190" stroke={strokeColor} strokeWidth="2.5" />
      <circle cx="200" cy="200" r="182" stroke={strokeColor} strokeWidth="1" />

      {/* Blue Sky */}
      <path 
        d="M50 210 C50 120 100 50 200 50 C300 50 350 120 350 210" 
        fill={skyColor} 
        stroke={strokeColor} 
        strokeWidth="1.5"
      />

      {/* Wall and Towers */}
      <path 
        d="M50 210 H130 V120 H140 V135 H150 V120 H160 V135 H170 V120 H180 V210 H220 V120 H230 V135 H240 V120 H250 V135 H260 V120 H270 V210 H350 V270 H50 V210 Z" 
        fill={wallColor} 
        stroke={strokeColor} 
        strokeWidth="1.5"
      />

      {/* Battlements along the wall top */}
      <path d="M70 185 H85 V210 H70 Z" fill={wallColor} stroke={strokeColor} strokeWidth="1" />
      <path d="M95 185 H110 V210 H95 Z" fill={wallColor} stroke={strokeColor} strokeWidth="1" />
      <path d="M290 185 H305 V210 H290 Z" fill={wallColor} stroke={strokeColor} strokeWidth="1" />
      <path d="M315 185 H330 V210 H315 Z" fill={wallColor} stroke={strokeColor} strokeWidth="1" />

      {/* Warrior between towers */}
      <g transform="translate(180, 115)">
        {/* Head/Helmet */}
        <circle cx="20" cy="15" r="8" fill={warriorColor} stroke={strokeColor} strokeWidth="1" />
        {/* Body */}
        <path d="M10 23 L5 55 H35 L30 23 Z" fill={warriorColor} stroke={strokeColor} strokeWidth="1" />
        {/* Arm with Sword */}
        <path d="M30 25 L50 5 L60 12 L40 35" fill={warriorColor} stroke={strokeColor} strokeWidth="1" />
        <path d="M55 2 L65 10" stroke={strokeColor} strokeWidth="3" strokeLinecap="round" />
        <path d="M58 5 L85 -20 L95 -12 L68 12 Z" fill={warriorColor} stroke={strokeColor} strokeWidth="1" />
      </g>

      {/* Arched Gate */}
      <path 
        d="M175 270 V225 C175 200 225 200 225 225 V270" 
        fill={gateColor} 
        stroke={strokeColor} 
        strokeWidth="1.5" 
      />
      
      {/* Anchor inside gate */}
      <g transform="translate(188, 225) scale(0.6)">
        <path d="M20 10 V65 M0 45 C0 65 40 65 40 45" stroke={warriorColor} strokeWidth="6" fill="none" strokeLinecap="round" />
        <circle cx="20" cy="8" r="6" stroke={warriorColor} strokeWidth="4" />
        <path d="M-5 45 L0 55 L5 45" stroke={warriorColor} strokeWidth="4" fill="none" />
        <path d="M35 45 L40 55 L45 45" stroke={warriorColor} strokeWidth="4" fill="none" />
      </g>

      {/* Water base and Waves */}
      <path d="M50 270 H350 V350 C350 350 280 340 200 340 C120 340 50 350 50 350 V270Z" fill={waterBase} stroke={strokeColor} strokeWidth="1" />
      
      <path 
        d="M50 305 Q125 285 200 305 T350 305 L350 325 Q275 305 200 325 T50 325 Z" 
        fill={waterWave} 
        stroke={strokeColor} 
        strokeWidth="1" 
      />
      <path 
        d="M50 330 Q125 310 200 330 T350 330 L350 350 Q275 330 200 350 T50 350 Z" 
        fill={waterWave} 
        stroke={strokeColor} 
        strokeWidth="1" 
      />

      {/* Brick Grid */}
      <g stroke={strokeColor} strokeWidth="0.5" opacity="0.4">
        <path d="M50 230 H175 M225 230 H350" />
        <path d="M50 250 H175 M225 250 H350" />
        <path d="M80 210 V270 M110 210 V270 M140 210 V270 M260 210 V270 M290 210 V270 M320 210 V270" />
      </g>

      {/* Text in Cyrillic precisely following the arc */}
      <defs>
        <path id="crestTopArc" d="M70 160 A130 130 0 0 1 330 160" />
        <path id="crestBottomArc" d="M100 280 A100 100 0 0 0 300 280" />
      </defs>

      <text fill={textColor} style={{ fontSize: '26px', fontWeight: '900', letterSpacing: '0.05em', fontFamily: 'Inter, sans-serif' }}>
        <textPath href="#crestTopArc" startOffset="50%" textAnchor="middle">ОПШТИНА КОВИН</textPath>
      </text>

      <text fill={textColor} style={{ fontSize: '32px', fontWeight: '900', letterSpacing: '0.2em', fontFamily: 'Inter, sans-serif' }}>
        <textPath href="#crestBottomArc" startOffset="50%" textAnchor="middle">КОВИН</textPath>
      </text>
    </svg>
  );
};

export default KovinGrb;
