
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, PlayerStats, UserRole } from '../types';
import { LogIn, Lock, User as UserIcon, AlertCircle } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
  players: PlayerStats[];
}

const Login: React.FC<LoginProps> = ({ onLogin, players }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Admin check
    if (username === 'admin' && password === 'admin123') {
      onLogin({ id: 'admin-1', username: 'admin', role: 'admin' });
      navigate('/');
      return;
    }

    // Player check
    const player = players.find(p => p.username === username && p.password === password);
    if (player) {
      onLogin({ id: `user-${player.id}`, username: player.username, role: 'player', playerId: player.id });
      navigate('/profil');
      return;
    }

    setError('Pogrešno korisničko ime ili lozinka.');
  };

  return (
    <div className="min-h-[60vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#0d1117] border-4 border-[#010409] p-10 md:p-16 shadow-[20px_20px_0px_#010409] sharp-border">
        <div className="flex flex-col items-center mb-12">
          <div className="bg-[#00d4ff] p-6 mb-6 sharp-border border-4 border-[#010409]">
            <LogIn size={40} className="text-[#010409]" />
          </div>
          <h2 className="text-4xl font-black italic uppercase tracking-tighter text-white">Prijava</h2>
          <p className="text-[10px] font-black text-[#484f58] uppercase tracking-[0.4em] mt-3">Gradska liga Kovin</p>
        </div>

        {error && (
          <div className="mb-8 p-6 bg-red-900/30 border-2 border-red-700 text-red-400 flex items-center gap-4 text-xs font-black uppercase tracking-widest sharp-border">
            <AlertCircle size={20} />
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-8">
          <div>
            <label className="block text-[10px] font-black text-[#00d4ff] uppercase tracking-[0.3em] mb-3">Korisničko Ime</label>
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-[#484f58]" size={20} />
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-[#010409] border-2 border-[#161b22] px-12 py-5 text-white font-black italic outline-none focus:border-[#00d4ff] transition-all sharp-border"
                placeholder="Unesite korisničko ime..."
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black text-[#00d4ff] uppercase tracking-[0.3em] mb-3">Lozinka</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#484f58]" size={20} />
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#010409] border-2 border-[#161b22] px-12 py-5 text-white font-black italic outline-none focus:border-[#00d4ff] transition-all sharp-border"
                placeholder="Unesite lozinku..."
                required
              />
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full bg-[#00d4ff] text-[#010409] py-6 font-black uppercase tracking-[0.2em] text-sm hover:bg-white transition-all shadow-[8px_8px_0px_#010409] sharp-border"
          >
            POTVRDI PRIJAVU
          </button>
        </form>

        <div className="mt-12 pt-8 border-t-2 border-[#161b22] text-center">
          <p className="text-[10px] font-black text-[#484f58] uppercase tracking-widest leading-relaxed">
            Sistem za igrače i administraciju.<br/>Lozinku dobijate od koordinatora lige.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
