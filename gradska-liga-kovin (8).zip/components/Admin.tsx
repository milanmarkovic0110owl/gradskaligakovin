
import React, { useState, useEffect } from 'react';
import { TeamMatch, IndividualMatch, PlayerStats } from '../types';
import { ChevronDown, ChevronUp, Save, Lock, Users, Share2, Check } from 'lucide-react';

interface AdminProps {
  matches: TeamMatch[];
  onUpdateMatch: (match: TeamMatch) => void;
  players: PlayerStats[];
  onFullUpdate: (players: PlayerStats[], matches: TeamMatch[]) => void;
  isAdmin: boolean;
}

const Admin: React.FC<AdminProps> = ({ matches, onUpdateMatch, players, isAdmin }) => {
  const [activeRound, setActiveRound] = useState(1);
  const [view, setView] = useState<'matches' | 'users'>('matches');
  const rounds = Array.from({ length: 9 }, (_, i) => i + 1);

  if (!isAdmin) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center p-8 bg-[#0d1117] sharp-border">
        <Lock className="text-[#00d4ff] mb-6" size={60} />
        <h2 className="text-2xl font-black uppercase text-white mb-4">Admin Pristup</h2>
        <p className="text-center text-white/60 font-black uppercase text-[10px] tracking-widest">Ovaj odeljak je samo za koordinatora lige.</p>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <div className="bg-red-800 p-8 md:p-12 border-4 border-[#020617] relative overflow-hidden sharp-border">
        <h2 className="text-3xl md:text-5xl font-black uppercase italic text-white leading-none">Admin Panel</h2>
        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-red-200 mt-2 italic">Rezultati se automatski šalju svim igračima.</p>
      </div>

      <div className="flex border-4 border-[#020617] bg-[#0f172a] sharp-border overflow-hidden">
        <button onClick={() => setView('matches')} className={`flex-1 py-6 font-black uppercase text-[10px] ${view === 'matches' ? 'bg-[#00d4ff] text-[#010409]' : 'text-white/70'}`}>REZULTATI</button>
        <button onClick={() => setView('users')} className={`flex-1 py-6 font-black uppercase text-[10px] ${view === 'users' ? 'bg-[#00d4ff] text-[#010409]' : 'text-white/70'}`}>NALOZI</button>
      </div>

      {view === 'matches' && (
        <div className="space-y-8">
          <div className="flex flex-wrap gap-2 border-4 border-[#020617] bg-[#0f172a] p-2 w-full md:w-fit sharp-border">
            {rounds.map(r => (
              <button key={r} onClick={() => setActiveRound(r)} className={`px-4 py-3 text-xs font-black sharp-border border-2 ${activeRound === r ? 'bg-white text-[#020617]' : 'bg-[#020617] text-[#8b949e]'}`}>{r}</button>
            ))}
          </div>
          <div className="grid grid-cols-1 gap-8">
            {matches.filter(m => m.round === activeRound).map(match => (
              <AdminMatchCard key={match.id} match={match} onUpdateMatch={onUpdateMatch} players={players} />
            ))}
          </div>
        </div>
      )}

      {view === 'users' && (
        <div className="bg-[#0d1117] border-4 border-[#020617] sharp-border overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-[#020617] text-[#8b949e] text-[10px] uppercase font-black">
              <tr>
                <th className="px-8 py-6">Igrač</th>
                <th className="px-8 py-6">User</th>
                <th className="px-8 py-6">Pass</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-[#020617]">
              {players.map(p => (
                <tr key={p.id} className="text-white text-xs">
                  <td className="px-8 py-4 font-black">{p.name}</td>
                  <td className="px-8 py-4 font-mono">{p.username}</td>
                  <td className="px-8 py-4 font-mono text-[#00d4ff]">{p.password}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

const AdminMatchCard: React.FC<{ match: TeamMatch; onUpdateMatch: (m: TeamMatch) => void; players: PlayerStats[] }> = ({ match, onUpdateMatch, players }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [localIM, setLocalIM] = useState<IndividualMatch[]>(match.individualMatches);

  const homePlayers = players.filter(p => p.teamId === match.homeTeamId);
  const awayPlayers = players.filter(p => p.teamId === match.awayTeamId);

  useEffect(() => { setLocalIM(match.individualMatches); }, [match.individualMatches]);

  const updateSet = (mIdx: number, sIdx: number, side: 'home' | 'away', val: string) => {
    const num = parseInt(val) || 0;
    const newList = [...localIM];
    const targetMatch = { ...newList[mIdx] };
    const targetSets = [...targetMatch.sets];
    while (targetSets.length <= sIdx) targetSets.push({ home: 0, away: 0 });
    targetSets[sIdx] = { ...targetSets[sIdx], [side]: num };
    targetMatch.sets = targetSets;

    let hWins = 0, aWins = 0;
    targetSets.forEach(s => { if (s.home > s.away) hWins++; else if (s.away > s.home) aWins++; });
    targetMatch.winner = hWins >= 3 ? 'home' : (aWins >= 3 ? 'away' : null);
    newList[mIdx] = targetMatch;
    setLocalIM(newList);
  };

  const calculateScore = () => {
    let h = 0, a = 0;
    localIM.forEach(im => { if (im.winner === 'home') h++; else if (im.winner === 'away') a++; });
    return { h, a };
  };

  const currentScore = calculateScore();

  return (
    <div className="bg-[#0f172a] border-4 border-[#020617] sharp-border overflow-hidden">
      <div className="flex flex-col md:flex-row items-center p-6 gap-6">
        <div className="flex-1 text-right font-black text-white uppercase italic">{match.homeTeamId}</div>
        <div className="bg-[#020617] px-8 py-4 sharp-border border-2 text-[#00d4ff] font-black text-3xl">
          {currentScore.h}:{currentScore.a}
        </div>
        <div className="flex-1 text-left font-black text-white uppercase italic">{match.awayTeamId}</div>
        <div className="flex gap-2">
           <button onClick={() => setIsOpen(!isOpen)} className="p-4 bg-[#0d1117] text-white">
            {isOpen ? <ChevronUp /> : <ChevronDown />}
           </button>
           {isOpen && (
             <button onClick={() => onUpdateMatch({...match, individualMatches: localIM, scoreHome: currentScore.h, scoreAway: currentScore.a, isCompleted: true})} className="bg-[#00d4ff] text-[#010409] px-6 py-4 font-black uppercase text-xs sharp-border flex items-center gap-2">
              <Save size={16} /> SAČUVAJ
             </button>
           )}
        </div>
      </div>
      {isOpen && (
        <div className="bg-[#020617] p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          {localIM.map((im, mIdx) => (
            <div key={im.id} className="bg-[#0f172a] p-4 border-2 border-[#1e293b] sharp-border">
              <div className="space-y-4">
                 <div>
                    <select value={im.homePlayerId} onChange={(e) => {
                      const newList = [...localIM];
                      newList[mIdx] = { ...newList[mIdx], homePlayerId: e.target.value };
                      setLocalIM(newList);
                    }} className="w-full bg-[#020617] border-2 border-[#1e293b] p-2 text-[9px] font-black uppercase text-[#00d4ff]">
                      <option value="">Izaberi Domaćina</option>
                      {homePlayers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                    <div className="flex gap-1 mt-2">
                      {[0,1,2,3,4].map(sIdx => <input key={sIdx} type="number" value={im.sets[sIdx]?.home ?? ''} onChange={(e) => updateSet(mIdx, sIdx, 'home', e.target.value)} className="w-full h-8 bg-[#020617] border border-[#1e293b] text-center text-white" />)}
                    </div>
                 </div>
                 <div>
                    <select value={im.awayPlayerId} onChange={(e) => {
                      const newList = [...localIM];
                      newList[mIdx] = { ...newList[mIdx], awayPlayerId: e.target.value };
                      setLocalIM(newList);
                    }} className="w-full bg-[#020617] border-2 border-[#1e293b] p-2 text-[9px] font-black uppercase text-[#00d4ff]">
                      <option value="">Izaberi Gosta</option>
                      {awayPlayers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                    <div className="flex gap-1 mt-2">
                      {[0,1,2,3,4].map(sIdx => <input key={sIdx} type="number" value={im.sets[sIdx]?.away ?? ''} onChange={(e) => updateSet(mIdx, sIdx, 'away', e.target.value)} className="w-full h-8 bg-[#020617] border border-[#1e293b] text-center text-white" />)}
                    </div>
                 </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Admin;
