
import React from 'react';
import { Team } from '../types';

interface StandingsProps {
  teams: Team[];
}

const Standings: React.FC<StandingsProps> = ({ teams }) => {
  const sortedTeams = [...teams].sort((a, b) => b.points - a.points || (b.matchesWon - b.matchesLost) - (a.matchesWon - a.matchesLost));

  return (
    <div className="bg-[#0d1117] border-4 border-[#010409] sharp-border overflow-hidden shadow-2xl">
      <div className="bg-[#010409] p-4 md:p-12 flex justify-between items-end border-b-4 border-[#161b22]">
        <div>
          <h2 className="text-xl md:text-5xl font-black uppercase tracking-tighter text-white italic leading-none">Tabela</h2>
          <p className="text-[7px] md:text-xs text-[#00d4ff] uppercase font-black tracking-[0.2em] md:tracking-[0.5em] mt-1 md:mt-4 italic">Sezona 2025</p>
        </div>
      </div>
      
      <div className="w-full overflow-x-auto md:overflow-x-visible">
        <table className="w-full text-left border-collapse table-auto min-w-full">
          <thead>
            <tr className="bg-[#010409] border-b-4 border-[#161b22] text-[#8b949e] text-[8px] md:text-[10px] uppercase font-black tracking-widest italic">
              <th className="px-1 py-3 md:px-4 md:py-8 text-center">Poz</th>
              <th className="px-1 py-3 md:px-4 md:py-8">Ekipa</th>
              <th className="px-1 py-3 md:px-4 md:py-8 text-center">M</th>
              <th className="px-1 py-3 md:px-4 md:py-8 text-center text-green-400">P</th>
              <th className="px-1 py-3 md:px-4 md:py-8 text-center text-red-400">I</th>
              <th className="px-1 py-3 md:px-4 md:py-8 text-center hidden sm:table-cell">Setovi</th>
              <th className="px-1 py-3 md:px-4 md:py-8 text-center bg-[#00d4ff] text-[#010409]">Bod</th>
            </tr>
          </thead>
          <tbody className="divide-y-2 divide-[#010409]">
            {sortedTeams.map((team, idx) => (
              <tr key={team.id} className="hover:bg-[#161b22] group transition-all">
                <td className="px-1 py-3 md:px-4 md:py-10 font-black text-sm md:text-6xl italic text-white/30 group-hover:text-[#00d4ff]/40 text-center">
                  {idx + 1}
                </td>
                <td className="px-1 py-3 md:px-4 md:py-10 font-black uppercase tracking-tighter text-white text-[10px] md:text-2xl italic group-hover:translate-x-1 transition-transform">
                  <div className="truncate max-w-[80px] sm:max-w-none">{team.name}</div>
                </td>
                <td className="px-1 py-3 md:px-4 md:py-10 text-center font-black text-[10px] md:text-xl text-white">
                  {team.played}
                </td>
                <td className="px-1 py-3 md:px-4 md:py-10 text-center font-black text-[10px] md:text-xl text-green-400">
                  {team.won}
                </td>
                <td className="px-1 py-3 md:px-4 md:py-10 text-center font-black text-[10px] md:text-xl text-red-400">
                  {team.lost}
                </td>
                <td className="px-1 py-3 md:px-4 md:py-10 text-center font-black text-[8px] md:text-xl text-white/70 italic hidden sm:table-cell">
                  {team.matchesWon}:{team.matchesLost}
                </td>
                <td className="px-1 py-3 md:px-4 md:py-10 text-center font-black text-sm md:text-6xl text-[#00d4ff] italic">
                  {team.points}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Standings;
