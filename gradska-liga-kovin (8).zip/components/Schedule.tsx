
import React, { useState } from 'react';
import { TeamMatch, PlayerStats } from '../types';
import { ChevronDown, ChevronUp, Swords, User, CalendarDays } from 'lucide-react';
import { SCHEDULE_RAW } from '../constants';

interface ScheduleProps {
  matches: TeamMatch[];
  players: PlayerStats[];
}

const Schedule: React.FC<ScheduleProps> = ({ matches, players }) => {
  const [activeRound, setActiveRound] = useState(1);
  const rounds = Array.from({ length: 9 }, (_, i) => i + 1);
  const activeRoundData = SCHEDULE_RAW.find(r => r.round === activeRound);

  return (
    <div className="space-y-4 md:space-y-10">
      {/* Header i Selektor Kola */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between bg-[#0d1117] border-4 border-[#010409] p-3 md:p-8 sharp-border">
          <div className="min-w-0">
            <span className="text-[7px] md:text-xs font-black text-[#00d4ff] uppercase tracking-widest italic block">Kolo {activeRound}</span>
            <h3 className="text-lg md:text-5xl font-[900] italic text-white uppercase tracking-tighter leading-none mt-1 truncate">{activeRoundData?.date}</h3>
          </div>
          <CalendarDays size={20} className="text-[#30363d] md:w-10 md:h-10 shrink-0" />
        </div>

        {/* Selektor kola */}
        <div className="w-full">
          <div className="text-[9px] md:text-xs font-black text-[#8b949e] uppercase tracking-[0.4em] mb-2 italic px-1">IZABERI KOLO</div>
          <div className="grid grid-cols-5 md:grid-cols-9 gap-1 bg-[#010409] p-1 border-2 border-[#161b22] sharp-border shadow-lg">
            {rounds.map(r => (
              <button 
                key={r} 
                onClick={() => setActiveRound(r)} 
                className={`py-3 md:py-6 text-xs md:text-xl font-black transition-all border-2 flex items-center justify-center ${activeRound === r ? 'bg-[#00d4ff] text-[#010409] border-[#00d4ff] z-10' : 'bg-[#0d1117] text-[#8b949e] border-[#161b22] hover:text-white'}`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Lista Mečeva */}
      <div className="grid grid-cols-1 gap-2 md:gap-6">
        {matches.filter(m => m.round === activeRound).map(match => (
          <MatchCard key={match.id} match={match} players={players} />
        ))}
      </div>
    </div>
  );
};

const MatchCard: React.FC<{ match: TeamMatch; players: PlayerStats[] }> = ({ match, players }) => {
  const [isOpen, setIsOpen] = useState(false);
  const getPlayerName = (id: string) => {
    const p = players.find(p => p.id === id);
    if (!p) return '-';
    const names = p.name.split(' ');
    return names.length > 1 ? names[names.length - 1] : p.name;
  };

  return (
    <div className="bg-[#0d1117] border-2 md:border-4 border-[#010409] sharp-border shadow-md overflow-hidden">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-2 md:p-6 hover:bg-[#161b22] transition-colors gap-2"
      >
        <div className="flex-1 text-right min-w-0">
          <span className="text-[10px] md:text-3xl font-black uppercase italic tracking-tighter text-white truncate block leading-none">
            {match.homeTeamId}
          </span>
        </div>
        
        <div className="bg-[#010409] text-[#00d4ff] px-3 py-1 md:px-8 md:py-4 border border-[#30363d] flex items-center justify-center gap-2 md:gap-4 shrink-0 mx-1">
          <span className="text-sm md:text-4xl font-black tabular-nums leading-none">{match.scoreHome}</span>
          <span className="text-[#30363d] font-black text-[10px] md:text-2xl leading-none">:</span>
          <span className="text-sm md:text-4xl font-black tabular-nums leading-none">{match.scoreAway}</span>
        </div>

        <div className="flex-1 text-left min-w-0">
          <span className="text-[10px] md:text-3xl font-black uppercase italic tracking-tighter text-white truncate block leading-none">
            {match.awayTeamId}
          </span>
        </div>

        <div className="text-[#8b949e] shrink-0 ml-1">
          {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </div>
      </button>
      
      {isOpen && (
        <div className="bg-[#010409] border-t-2 border-[#161b22] overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[280px]">
            <thead>
              <tr className="bg-[#0d1117] border-b border-[#161b22] text-[7px] md:text-[9px] font-black text-[#8b949e] uppercase tracking-widest italic">
                <th className="p-2 w-6 text-center">#</th>
                <th className="p-2">Domaćin</th>
                <th className="p-2">Gost</th>
                <th className="p-2 text-center">Setovi</th>
                <th className="p-2 text-right">R</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161b22]">
              {match.individualMatches.map((im, mIdx) => {
                const isHomeWinner = im.winner === 'home';
                const isAwayWinner = im.winner === 'away';
                
                let hSets = 0, aSets = 0;
                im.sets.forEach(s => { if(s.home > s.away) hSets++; else if(s.away > s.home) aSets++; });

                return (
                  <tr key={im.id} className="hover:bg-[#0d1117]/50 text-[9px] md:text-sm">
                    <td className="p-2 font-black text-white/30 italic text-center">{mIdx + 1}</td>
                    <td className={`p-2 font-black uppercase italic truncate max-w-[80px] md:max-w-none ${isHomeWinner ? 'text-[#00d4ff]' : 'text-white/80'}`}>
                      {getPlayerName(im.homePlayerId)}
                    </td>
                    <td className={`p-2 font-black uppercase italic truncate max-w-[80px] md:max-w-none ${isAwayWinner ? 'text-[#00d4ff]' : 'text-white/80'}`}>
                      {getPlayerName(im.awayPlayerId)}
                    </td>
                    <td className="p-2">
                      <div className="flex justify-center gap-0.5 md:gap-1">
                        {im.sets.map((s, si) => (
                          <div key={si} className="flex flex-col text-[7px] md:text-[10px] font-black bg-[#0d1117] px-0.5 border border-[#161b22] min-w-[14px] text-center">
                            <span className={s.home > s.away ? 'text-[#00d4ff]' : 'text-white/40'}>{s.home}</span>
                            <span className={s.away > s.home ? 'text-[#00d4ff]' : 'text-white/40'}>{s.away}</span>
                          </div>
                        ))}
                      </div>
                    </td>
                    <td className="p-2 text-right">
                      <span className={`font-black italic text-[10px] md:text-sm ${im.winner ? 'text-white' : 'text-[#8b949e]'}`}>
                        {hSets}:{aSets}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Schedule;
