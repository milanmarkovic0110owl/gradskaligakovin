
import React from 'react';
import { Team, TeamMatch } from '../types';
import { Trophy, CalendarDays, ArrowRight, TrendingUp, Users, Target } from 'lucide-react';
import { Link } from 'react-router-dom';

interface DashboardProps {
  matches: TeamMatch[];
  teams: Team[];
}

const Dashboard: React.FC<DashboardProps> = ({ matches, teams }) => {
  // Povećano na 5 da bi se videlo celo kolo (svih 5 parova)
  const nextRoundMatches = matches.filter(m => !m.isCompleted).slice(0, 5);

  return (
    <div className="space-y-4 md:space-y-8">
      {/* Hero Section */}
      <div className="bg-[#010409] min-h-[300px] md:min-h-[500px] border-4 border-[#0d1117] relative overflow-hidden flex items-center sharp-border shadow-2xl px-6 md:px-20 py-10">
         <div className="relative z-10 w-full flex flex-col items-center md:items-start text-center md:text-left">
            <h1 className="text-4xl sm:text-6xl md:text-9xl font-[900] text-white uppercase tracking-tighter italic leading-none mb-6">
               GRADSKA LIGA<br/>
               <span className="text-[#00d4ff] not-italic safe-text-render text-6xl md:text-[11rem] block mt-2">KOVIN</span>
            </h1>
            <Link to="/raspored" className="inline-flex items-center gap-2 bg-[#00d4ff] text-[#010409] px-8 md:px-14 py-4 md:py-8 font-black uppercase text-xs md:text-xl tracking-[0.2em] sharp-border hover:bg-white transition-all shadow-[8px_8px_0px_#010409] mt-6">
               RASPORED <ArrowRight size={24} />
            </Link>
         </div>
         <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-[#00d4ff]/5 to-transparent pointer-events-none"></div>
      </div>

      <div className="grid grid-cols-3 gap-2 md:gap-8">
        <StatTile label="KOLO" value="1." icon={<CalendarDays size={18} className="text-[#00d4ff]" />} />
        <StatTile label="EKIPE" value="10" icon={<Trophy size={18} className="text-[#00d4ff]" />} />
        <StatTile label="IGRAČI" value="30" icon={<Users size={18} className="text-[#00d4ff]" />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-10">
        <section className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center bg-[#0d1117] p-4 md:p-8 border-4 border-[#010409] sharp-border">
             <div className="flex items-center gap-2">
                <div className="w-1 h-4 md:w-2 md:h-8 bg-[#00d4ff]"></div>
                <h2 className="font-black uppercase tracking-widest text-[9px] md:text-lg text-white">Sledeći mečevi</h2>
             </div>
             <TrendingUp size={16} className="text-[#8b949e]" />
          </div>
          <div className="grid gap-2">
            {nextRoundMatches.length > 0 ? nextRoundMatches.map(m => (
              <div key={m.id} className="bg-[#0d1117] p-3 md:p-8 border-4 border-[#010409] flex items-center justify-between group relative overflow-hidden sharp-border gap-2">
                <div className="flex-1 text-center sm:text-right min-w-0">
                   <div className="text-[10px] md:text-2xl font-[900] italic uppercase tracking-tighter text-white truncate leading-none">{m.homeTeamId}</div>
                </div>
                <div className="flex flex-col items-center shrink-0 min-w-[80px] md:min-w-[140px]">
                   <div className="text-sm md:text-2xl font-black text-[#00d4ff] italic opacity-80 mb-1">VS</div>
                   <div className="text-[10px] md:text-sm font-black text-white bg-[#010409] px-2 py-1 uppercase border border-[#30363d] whitespace-nowrap">{m.date.split(' ')[0]}</div>
                </div>
                <div className="flex-1 text-center sm:text-left min-w-0">
                   <div className="text-[10px] md:text-2xl font-[900] italic uppercase tracking-tighter text-white truncate leading-none">{m.awayTeamId}</div>
                </div>
              </div>
            )) : (
              <div className="bg-[#0d1117] p-8 text-center border-4 border-[#010409] sharp-border">
                <span className="text-[#484f58] font-black uppercase text-xs tracking-widest italic">Nema predstojećih mečeva</span>
              </div>
            )}
          </div>
        </section>

        <section className="bg-[#0d1117] border-4 border-[#010409] flex flex-col h-fit sharp-border">
          <div className="bg-[#010409] p-4 md:p-8 flex items-center justify-between border-b-4 border-[#161b22]">
            <h2 className="font-black uppercase tracking-widest text-[9px] md:text-base text-[#00d4ff]">TOP 5</h2>
            <Target size={18} className="text-white opacity-60" />
          </div>
          <div className="p-2">
            <table className="w-full">
              <tbody className="divide-y-2 divide-[#010409]">
                {teams.slice(0, 5).map((t, idx) => (
                  <tr key={idx} className="hover:bg-[#161b22] transition-colors group">
                    <td className="p-2 font-black text-white/40 italic text-xl md:text-4xl w-10 text-center">{idx + 1}</td>
                    <td className="p-2 font-black uppercase text-[10px] md:text-xs text-white truncate">{t.name}</td>
                    <td className="p-2 text-right font-[900] text-sm md:text-2xl text-[#00d4ff] italic">{t.points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
};

const StatTile: React.FC<{ label: string; value: string; icon: React.ReactNode }> = ({ label, value, icon }) => (
  <div className="bg-[#0d1117] p-3 md:p-8 border-4 border-[#010409] flex items-center justify-between group transition-all hover:bg-[#161b22] sharp-border shadow-md overflow-hidden">
    <div className="min-w-0 flex-1 pr-1">
      <span className="text-[7px] font-black text-[#8b949e] uppercase tracking-widest block mb-1">{label}</span>
      <div className="text-sm md:text-4xl font-[900] italic text-white leading-none truncate">{value}</div>
    </div>
    <div className="bg-[#010409] p-1 md:p-4 border-2 border-[#161b22] shrink-0 sharp-border">
      {icon}
    </div>
  </div>
);

export default Dashboard;
