
import React from 'react';
import { useParams } from 'react-router-dom';
import { PlayerStats, TeamMatch } from '../types';
import { User, Trophy, BarChart, History, Calendar } from 'lucide-react';

interface PlayerDetailProps {
  players: PlayerStats[];
  matches: TeamMatch[];
}

const PlayerDetail: React.FC<PlayerDetailProps> = ({ players, matches }) => {
  const { playerId } = useParams<{ playerId: string }>();
  const player = players.find(p => p.id === decodeURIComponent(playerId || ''));

  if (!player) return <div className="p-4 text-white font-black uppercase tracking-widest text-[10px]">Igrač nije pronađen.</div>;

  // Pronalaženje svih pojedinačnih partija ovog igrača
  const playerHistory = matches.filter(m => m.isCompleted).flatMap(m => {
    return m.individualMatches
      .filter(im => im.homePlayerId === player.id || im.awayPlayerId === player.id)
      .map(im => {
        const isHome = im.homePlayerId === player.id;
        const opponentId = isHome ? im.awayPlayerId : im.homePlayerId;
        const opponent = players.find(p => p.id === opponentId);
        
        // Izračunavanje rezultata u setovima za ovu partiju
        let playerSets = 0;
        let opponentSets = 0;
        im.sets.forEach(s => {
          if (isHome) {
            if (s.home > s.away) playerSets++; else if (s.away > s.home) opponentSets++;
          } else {
            if (s.away > s.home) playerSets++; else if (s.home > s.away) opponentSets++;
          }
        });

        const won = (isHome && im.winner === 'home') || (!isHome && im.winner === 'away');

        return {
          id: im.id,
          date: m.date,
          round: m.round,
          opponent: opponent?.name || 'Nepoznat protivnik',
          opponentTeam: opponent?.teamId || 'Nepoznat tim',
          score: `${playerSets} : ${opponentSets}`,
          won,
          sets: im.sets
        };
      });
  }).sort((a, b) => b.round - a.round); // Najnoviji mečevi prvi

  const winRate = player.matchesPlayed > 0 ? Math.round((player.matchesWon / player.matchesPlayed) * 100) : 0;

  return (
    <div className="space-y-4">
      {/* Header Profile */}
      <div className="bg-[#0d1117] p-4 md:p-12 border-4 border-[#010409] flex flex-row items-center gap-4 md:gap-10 sharp-border overflow-hidden relative">
        <div className="absolute right-0 top-0 opacity-5 pointer-events-none">
           <User size={200} />
        </div>
        <div className="w-16 h-16 md:w-32 md:h-32 bg-[#010409] border-2 border-[#161b22] flex items-center justify-center sharp-border shrink-0">
          {player.imageUrl ? (
            <img src={player.imageUrl} alt={player.name} className="w-full h-full object-cover" />
          ) : (
            <User size={40} className="text-[#161b22]" />
          )}
        </div>
        <div className="min-w-0 z-10">
          <h2 className="text-xl md:text-5xl font-black italic uppercase tracking-tighter text-white truncate leading-none mb-2">{player.name}</h2>
          <div className="flex flex-wrap gap-2">
            <span className="bg-[#161b22] px-3 py-1 border border-[#30363d] text-[#00d4ff] font-black uppercase text-[8px] md:text-xs tracking-widest italic">{player.teamId}</span>
            <span className="bg-[#161b22] px-3 py-1 border border-[#30363d] text-white font-black uppercase text-[8px] md:text-xs tracking-widest italic">{winRate}% WIN RATE</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Stats Summary */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-[#0d1117] p-4 border-4 border-[#010409] sharp-border">
            <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] mb-4 flex items-center gap-2 italic">
              <Trophy size={14} /> STATISTIKA SEZONE
            </h3>
            <div className="grid grid-cols-2 gap-2">
              <StatTile label="Pobede" value={player.matchesWon} color="text-green-500" />
              <StatTile label="Porazi" value={player.matchesLost} color="text-red-500" />
              <StatTile label="Setovi (+)" value={player.setsWon} />
              <StatTile label="Setovi (-)" value={player.setsLost} />
              <StatTile label="Poeni (+)" value={player.pointsWon} />
              <StatTile label="Poeni (-)" value={player.pointsLost} />
            </div>
          </div>

          <div className="bg-[#0d1117] p-4 border-4 border-[#010409] sharp-border">
             <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] mb-4 flex items-center gap-2 italic">
               <BarChart size={14} /> UČINAK
             </h3>
             <div className="space-y-4">
                <ProgressBar label="Partije Pobede" val={player.matchesWon} max={player.matchesPlayed} color="bg-[#00d4ff]" />
                <ProgressBar label="Setovi Pobede" val={player.setsWon} max={player.setsWon + player.setsLost} color="bg-white" />
             </div>
          </div>
        </div>

        {/* Match History */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#0d1117] border-4 border-[#010409] sharp-border">
            <div className="bg-[#010409] p-4 border-b-2 border-[#161b22] flex items-center justify-between">
               <h3 className="text-[9px] md:text-xs font-black uppercase tracking-widest text-[#00d4ff] italic flex items-center gap-2">
                 <History size={14} /> ISTORIJA PARTIJA
               </h3>
               <span className="text-[7px] md:text-[9px] font-black text-white/20 uppercase tracking-widest">{playerHistory.length} MEČEVA</span>
            </div>
            <div className="divide-y-2 divide-[#010409] max-h-[600px] overflow-y-auto scrollbar-hide">
              {playerHistory.length > 0 ? playerHistory.map(h => (
                <div key={h.id} className="p-4 flex items-center justify-between hover:bg-[#161b22] transition-colors group">
                  <div className="flex flex-col gap-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-[7px] md:text-[9px] font-black text-[#484f58] uppercase tracking-widest italic flex items-center gap-1">
                        <Calendar size={10} /> KOLO {h.round} / {h.date}
                      </span>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[10px] md:text-sm font-black text-white uppercase italic group-hover:text-[#00d4ff] transition-colors truncate">
                        vs {h.opponent}
                      </span>
                      <span className="text-[7px] md:text-[8px] font-black text-[#484f58] uppercase tracking-widest">{h.opponentTeam}</span>
                    </div>
                  </div>
                  <div className="text-right flex flex-col items-end gap-1">
                    <div className={`text-[12px] md:text-2xl font-[900] italic px-3 py-1 border-2 sharp-border shadow-sm ${h.won ? 'bg-[#00d4ff] text-[#010409] border-white' : 'bg-[#010409] text-white border-[#161b22]'}`}>
                      {h.score}
                    </div>
                    <span className={`text-[7px] font-black uppercase tracking-widest ${h.won ? 'text-[#00d4ff]' : 'text-red-500'}`}>
                      {h.won ? 'POBEDA' : 'PORAZ'}
                    </span>
                  </div>
                </div>
              )) : (
                <div className="p-10 text-center opacity-20 font-black uppercase text-[10px] tracking-widest">Nema odigranih partija.</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatTile: React.FC<{ label: string, value: number, color?: string }> = ({ label, value, color = "text-white" }) => (
  <div className="bg-[#010409] p-2 border border-[#161b22] sharp-border flex flex-col justify-center">
    <span className="text-[7px] font-black text-[#484f58] uppercase tracking-widest mb-1">{label}</span>
    <span className={`text-sm md:text-xl font-black italic leading-none ${color}`}>{value}</span>
  </div>
);

const ProgressBar: React.FC<{ label: string, val: number, max: number, color: string }> = ({ label, val, max, color }) => (
  <div>
    <div className="flex justify-between mb-1">
      <span className="text-[8px] font-black text-[#484f58] uppercase">{label}</span>
      <span className="text-[8px] font-black text-white">{val}/{max}</span>
    </div>
    <div className="h-1.5 bg-[#010409] border border-[#161b22]">
      <div className={`h-full ${color}`} style={{ width: `${Math.min(100, (val / (max || 1)) * 100)}%` }}></div>
    </div>
  </div>
);

export default PlayerDetail;
