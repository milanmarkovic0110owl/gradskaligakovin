
import React from 'react';
import { PlayerStats } from '../types';
import { User } from 'lucide-react';
import { Link } from 'react-router-dom';

interface PlayersProps {
  players: PlayerStats[];
}

const Players: React.FC<PlayersProps> = ({ players }) => {
  return (
    <div className="space-y-4">
      <div className="bg-[#0d1117] p-4 md:p-10 border-4 border-[#010409] flex flex-row justify-between items-center gap-4 sharp-border">
        <div>
          <h2 className="text-xl md:text-5xl font-black uppercase tracking-tighter text-white italic leading-none">Igrači</h2>
          <p className="text-[8px] md:text-sm text-[#00d4ff] uppercase font-black tracking-widest mt-2 italic">Učinak lige 2025</p>
        </div>
        <div className="bg-[#010409] px-6 py-3 border-2 border-[#161b22] sharp-border">
          <span className="text-[10px] md:text-base font-black text-white/80 uppercase tracking-widest">Ukupno: <span className="text-[#00d4ff]">{players.length}</span></span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 md:gap-8">
        {players.map(player => (
          <Link 
            key={player.id} 
            to={`/igraci/${encodeURIComponent(player.id)}`} 
            className="bg-[#0d1117] border-2 md:border-4 border-[#010409] flex items-stretch h-[100px] md:h-auto overflow-hidden transition-all hover:bg-[#161b22] group sharp-border"
          >
            <div className="w-[100px] md:w-40 bg-[#010409] border-r-2 border-[#161b22] flex items-center justify-center shrink-0 overflow-hidden">
               {player.imageUrl ? (
                 <img src={player.imageUrl} alt={player.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
               ) : (
                 <User size={40} className="text-[#161b22] group-hover:text-[#00d4ff] transition-colors" />
               )}
            </div>
            <div className="flex-1 p-3 md:p-8 flex flex-col justify-center min-w-0">
               <div className="flex justify-between items-start mb-2">
                  <h3 className="text-[11px] md:text-2xl font-black italic uppercase text-white truncate pr-2 group-hover:text-[#00d4ff] transition-colors">{player.name}</h3>
                  <span className="text-[9px] md:text-sm font-black text-[#00d4ff] italic bg-[#010409] px-1.5 py-0.5 border border-[#30363d]">{player.matchesPlayed > 0 ? `${Math.round((player.matchesWon / player.matchesPlayed) * 100)}%` : '0%'}</span>
               </div>
               <div className="text-[8px] md:text-xs font-black text-[#9ca3af] uppercase tracking-widest mb-3 truncate italic">{player.teamId}</div>
               <div className="flex gap-3">
                  <div className="flex flex-col">
                    <span className="text-[6px] md:text-[8px] font-black text-[#9ca3af] uppercase">Mečevi</span>
                    <div className="text-[10px] md:text-base font-black text-white px-2 py-0.5 bg-[#010409] border border-[#161b22]">{player.matchesWon}:{player.matchesLost}</div>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[6px] md:text-[8px] font-black text-[#9ca3af] uppercase">Setovi</span>
                    <div className="text-[10px] md:text-base font-black text-[#00d4ff] px-2 py-0.5 bg-[#010409] border border-[#161b22]">{player.setsWon}:{player.setsLost}</div>
                  </div>
               </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Players;
