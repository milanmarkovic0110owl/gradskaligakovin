
import { Team, PlayerStats } from './types';

export const TEAMS: string[] = [
  "SPINERI", "VETERANI DELIBLATO", "BOLNICA", "UJEDINJENI", "CENTAR", 
  "VETERANI GAJ", "VZP AUTO", "ZMAJEVI", "DOBRI LJUDI", "JEZGRO"
];

// Inicijalni igrači - Admin može ovde menjati imena pre puštanja u rad
export const INITIAL_PLAYERS: PlayerStats[] = TEAMS.flatMap(team => {
  const teamSlug = team.toLowerCase().replace(/\s/g, '');
  return [
    {
      id: `${team}-p1`,
      name: `Igrač 1 (${team})`,
      teamId: team,
      matchesPlayed: 0,
      matchesWon: 0,
      matchesLost: 0,
      setsWon: 0,
      setsLost: 0,
      pointsWon: 0,
      pointsLost: 0,
      username: `${teamSlug}_1`,
      password: 'lk' + Math.floor(1000 + Math.random() * 9000) // Nasumična početna lozinka
    },
    {
      id: `${team}-p2`,
      name: `Igrač 2 (${team})`,
      teamId: team,
      matchesPlayed: 0,
      matchesWon: 0,
      matchesLost: 0,
      setsWon: 0,
      setsLost: 0,
      pointsWon: 0,
      pointsLost: 0,
      username: `${teamSlug}_2`,
      password: 'lk' + Math.floor(1000 + Math.random() * 9000)
    },
    {
      id: `${team}-p3`,
      name: `Igrač 3 (${team})`,
      teamId: team,
      matchesPlayed: 0,
      matchesWon: 0,
      matchesLost: 0,
      setsWon: 0,
      setsLost: 0,
      pointsWon: 0,
      pointsLost: 0,
      username: `${teamSlug}_3`,
      password: 'lk' + Math.floor(1000 + Math.random() * 9000)
    }
  ];
});

export const SCHEDULE_RAW = [
  { round: 1, date: "01.02.2025 (Subota)", matches: [["SPINERI", "VETERANI DELIBLATO"], ["BOLNICA", "UJEDINJENI"], ["CENTAR", "VETERANI GAJ"], ["VZP AUTO", "ZMAJEVI"], ["DOBRI LJUDI", "JEZGRO"]] },
  { round: 2, date: "08.02.2025 (Subota)", matches: [["JEZGRO", "VETERANI DELIBLATO"], ["ZMAJEVI", "DOBRI LJUDI"], ["VETERANI GAJ", "VZP AUTO"], ["UJEDINJENI", "CENTAR"], ["SPINERI", "BOLNICA"]] },
  { round: 3, date: "15.02.2025 (Subota)", matches: [["DOBRI LJUDI", "VETERANI DELIBLATO"], ["JEZGRO", "VZP AUTO"], ["ZMAJEVI", "CENTAR"], ["VETERANI GAJ", "BOLNICA"], ["UJEDINJENI", "SPINERI"]] },
  { round: 4, date: "22.02.2025 (Subota)", matches: [["VZP AUTO", "VETERANI DELIBLATO"], ["DOBRI LJUDI", "CENTAR"], ["JEZGRO", "BOLNICA"], ["ZMAJEVI", "SPINERI"], ["VETERANI GAJ", "UJEDINJENI"]] },
  { round: 5, date: "01.03.2025 (Subota)", matches: [["CENTAR", "VETERANI DELIBLATO"], ["VZP AUTO", "BOLNICA"], ["DOBRI LJUDI", "SPINERI"], ["JEZGRO", "UJEDINJENI"], ["ZMAJEVI", "VETERANI GAJ"]] },
  { round: 6, date: "08.03.2025 (Subota)", matches: [["BOLNICA", "VETERANI DELIBLATO"], ["CENTAR", "SPINERI"], ["VZP AUTO", "UJEDINJENI"], ["DOBRI LJUDI", "VETERANI GAJ"], ["JEZGRO", "ZMAJEVI"]] },
  { round: 7, date: "15.03.2025 (Subota)", matches: [["ZMAJEVI", "VETERANI DELIBLATO"], ["VETERANI GAJ", "JEZGRO"], ["UJEDINJENI", "DOBRI LJUDI"], ["SPINERI", "VZP AUTO"], ["BOLNICA", "CENTAR"]] },
  { round: 8, date: "22.03.2025 (Subota)", matches: [["UJEDINJENI", "VETERANI DELIBLATO"], ["SPINERI", "VETERANI GAJ"], ["BOLNICA", "ZMAJEVI"], ["CENTAR", "JEZGRO"], ["VZP AUTO", "DOBRI LJUDI"]] },
  { round: 9, date: "29.03.2025 (Subota)", matches: [["VETERANI GAJ", "VETERANI DELIBLATO"], ["UJEDINJENI", "ZMAJEVI"], ["SPINERI", "JEZGRO"], ["BOLNICA", "DOBRI LJUDI"], ["CENTAR", "VZP AUTO"]] },
];
