
import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route, Link, useLocation, Navigate, useNavigate } from 'react-router-dom';
import { 
  Trophy, Calendar, Users, BarChart3, LayoutDashboard, Menu, X, Lock, 
  UserCircle, LogIn, LogOut, ArrowLeft
} from 'lucide-react';

// Firebase Imports (Directly from ESM)
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js';
import { getFirestore, doc, onSnapshot, setDoc, getDoc } from 'https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js';

import { TEAMS, SCHEDULE_RAW, INITIAL_PLAYERS } from './constants';
import { Team, TeamMatch, PlayerStats, User } from './types';

// Components
import Dashboard from './components/Dashboard';
import Schedule from './components/Schedule';
import Standings from './components/Standings';
import Statistics from './components/Statistics';
import Admin from './components/Admin';
import Players from './components/Players';
import Login from './components/Login';
import Profile from './components/Profile';
import TeamDetail from './components/TeamDetail';
import PlayerDetail from './components/PlayerDetail';

/**
 * OVDE ZAMENI SA TVOJIM KONFIGOM IZ FIREBASE CONSOLE!
 * Ako ostaviš prazno, aplikacija će raditi samo lokalno.
 */
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "liga-kovin.firebaseapp.com",
  projectId: "liga-kovin",
  storageBucket: "liga-kovin.appspot.com",
  messagingSenderId: "...",
  appId: "..."
};

// Inicijalizacija Firebase-a
let db: any = null;
try {
  const app = initializeApp(firebaseConfig);
  db = getFirestore(app);
} catch (e) {
  console.warn("Firebase nije konfigurisan. Podaci će biti samo lokalni.");
}

const SubPageHeader = () => {
  const navigate = useNavigate();
  const location = useLocation();
  if (location.pathname === '/') return null;
  return (
    <div className="w-full flex flex-col items-center mb-8 relative">
      <div className="w-full flex items-center justify-between border-b-2 border-[#161b22] pb-4">
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 px-3 py-1.5 md:px-5 md:py-3 bg-[#161b22] border-2 border-[#30363d] text-[#00d4ff] font-black uppercase text-[9px] md:text-[11px] tracking-widest sharp-border hover:bg-[#00d4ff] hover:text-[#010409] transition-all group shrink-0">
          <ArrowLeft size={14} /> Nazad
        </button>
        <div className="absolute left-1/2 -translate-x-1/2 flex flex-col items-center text-center">
           <span className="text-white/60 font-black text-[6px] md:text-[8px] uppercase tracking-[0.3em] leading-none mb-1">GRADSKA LIGA</span>
           <span className="text-[#00d4ff] uppercase text-sm md:text-xl font-[900] tracking-tight block leading-none">KOVIN</span>
        </div>
        <div className="w-[80px] md:w-[120px] invisible"></div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('kovin_league_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [matches, setMatches] = useState<TeamMatch[]>([]);
  const [basePlayers, setBasePlayers] = useState<PlayerStats[]>([]);

  // Real-time sinhronizacija sa Cloud-om
  useEffect(() => {
    if (!db) {
      setLoading(false);
      return;
    }

    // Slušamo promene u bazi (Real-time)
    const unsub = onSnapshot(doc(db, "league", "data"), (docSnap) => {
      if (docSnap.exists()) {
        const cloudData = docSnap.data();
        setMatches(cloudData.matches || []);
        setBasePlayers(cloudData.players || []);
      } else {
        // Ako je baza prazna, postavi početne vrednosti
        const initialMatches = SCHEDULE_RAW.flatMap(round => 
          round.matches.map((m, idx) => ({
            id: `r${round.round}-m${idx}`,
            round: round.round,
            date: round.date,
            homeTeamId: m[0],
            awayTeamId: m[1],
            individualMatches: Array.from({ length: 6 }).map((_, i) => ({
              id: `r${round.round}-m${idx}-i${i}`,
              homePlayerId: '',
              awayPlayerId: '',
              sets: [],
              winner: null
            })),
            isCompleted: false,
            scoreHome: 0,
            scoreAway: 0
          }))
        );
        setMatches(initialMatches);
        setBasePlayers(INITIAL_PLAYERS);
      }
      setLoading(false);
    });

    return () => unsub();
  }, []);

  const { players, teams } = useMemo(() => {
    const playerMap = new Map<string, PlayerStats>();
    basePlayers.forEach(p => {
      playerMap.set(p.id, { ...p, matchesPlayed: 0, matchesWon: 0, matchesLost: 0, setsWon: 0, setsLost: 0, pointsWon: 0, pointsLost: 0 });
    });

    const teamMap = new Map<string, Team>();
    TEAMS.forEach(name => {
      teamMap.set(name, { id: name, name, played: 0, won: 0, lost: 0, matchesWon: 0, matchesLost: 0, setsWon: 0, setsLost: 0, points: 0 });
    });

    matches.filter(m => m.isCompleted).forEach(m => {
      const homeTeam = teamMap.get(m.homeTeamId);
      const awayTeam = teamMap.get(m.awayTeamId);
      if (homeTeam && awayTeam) {
        homeTeam.played++; awayTeam.played++;
        homeTeam.matchesWon += m.scoreHome; homeTeam.matchesLost += m.scoreAway;
        awayTeam.matchesWon += m.scoreAway; awayTeam.matchesLost += m.scoreHome;
        if (m.scoreHome > m.scoreAway) { homeTeam.won++; homeTeam.points += 2; awayTeam.lost++; }
        else if (m.scoreAway > m.scoreHome) { awayTeam.won++; awayTeam.points += 2; homeTeam.lost++; }
      }
      m.individualMatches.forEach(im => {
        const hp = playerMap.get(im.homePlayerId);
        const ap = playerMap.get(im.awayPlayerId);
        if (hp && ap) {
          hp.matchesPlayed++; ap.matchesPlayed++;
          let hSets = 0, aSets = 0;
          im.sets.forEach(s => {
            hp.pointsWon += s.home; hp.pointsLost += s.away;
            ap.pointsWon += s.away; ap.pointsLost += s.home;
            if (s.home > s.away) hSets++; else if (s.away > s.home) aSets++;
          });
          hp.setsWon += hSets; hp.setsLost += aSets;
          ap.setsWon += aSets; ap.setsLost += hSets;
          if (im.winner === 'home') { hp.matchesWon++; ap.matchesLost++; }
          else if (im.winner === 'away') { ap.matchesWon++; hp.matchesLost++; }
          if (homeTeam) { homeTeam.setsWon += hSets; homeTeam.setsLost += aSets; }
          if (awayTeam) { awayTeam.setsWon += aSets; awayTeam.setsLost += hSets; }
        }
      });
    });
    return { players: Array.from(playerMap.values()), teams: Array.from(teamMap.values()) };
  }, [matches, basePlayers]);

  const handleUpdateCloud = async (newMatches: TeamMatch[], newPlayers: PlayerStats[]) => {
    if (db) {
      await setDoc(doc(db, "league", "data"), {
        matches: newMatches,
        players: newPlayers,
        lastUpdate: Date.now()
      });
    }
  };

  const handleUpdateMatch = async (updatedMatch: TeamMatch) => {
    const newMatches = matches.map(m => m.id === updatedMatch.id ? updatedMatch : m);
    setMatches(newMatches);
    await handleUpdateCloud(newMatches, basePlayers);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('kovin_league_user');
    setIsMobileMenuOpen(false);
  };

  if (loading) return <div className="min-h-screen bg-[#010409] flex items-center justify-center text-[#00d4ff] font-black uppercase tracking-[0.5em]">Učitavanje...</div>;

  return (
    <HashRouter>
      <div className="flex flex-col lg:flex-row min-h-screen bg-[#010409]">
        {/* Mobile Header */}
        <div className="lg:hidden bg-[#0d1117] text-white p-4 flex justify-between items-center border-b-4 border-[#010409] sticky top-0 z-50">
          <div className="flex flex-col">
             <span className="font-black text-white/60 text-[8px] uppercase tracking-widest leading-none">Gradska liga</span>
             <span className="text-[#00d4ff] uppercase text-xl font-[900] tracking-tight block leading-none">KOVIN</span>
          </div>
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-3 bg-[#161b22] sharp-border border-2 border-[#010409]">
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Sidebar */}
        <nav className={`fixed inset-0 z-[60] lg:relative lg:translate-x-0 transform transition-transform duration-300 ease-in-out bg-[#0d1117] w-full lg:w-80 flex-shrink-0 border-r-4 border-[#010409] ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="p-6 lg:p-10 h-full flex flex-col relative overflow-y-auto scrollbar-hide">
            <div className="lg:hidden flex justify-between items-center mb-8 pb-4 border-b border-[#161b22]">
              <span className="font-black text-[#00d4ff] text-xs uppercase tracking-[0.3em] italic">Meni</span>
              <button onClick={() => setIsMobileMenuOpen(false)} className="text-white/60"><X size={24} /></button>
            </div>
            <div className="hidden lg:flex flex-col mb-12">
                <h1 className="text-xs font-black text-white/40 uppercase tracking-[0.3em] leading-none mb-2">Gradska liga</h1>
                <span className="text-[#00d4ff] text-5xl xl:text-7xl tracking-tighter uppercase font-[900] block leading-none">KOVIN</span>
                <div className="h-[6px] w-full bg-[#00d4ff] mt-6"></div>
            </div>
            <ul className="space-y-2 lg:space-y-4 flex-1">
              <NavItem to="/" icon={<LayoutDashboard size={20}/>} label="Tabla" onClick={() => setIsMobileMenuOpen(false)} />
              <NavItem to="/raspored" icon={<Calendar size={20}/>} label="Raspored" onClick={() => setIsMobileMenuOpen(false)} />
              <NavItem to="/tabela" icon={<Trophy size={20}/>} label="Tabela" onClick={() => setIsMobileMenuOpen(false)} />
              <NavItem to="/statistika" icon={<BarChart3 size={20}/>} label="Analitika" onClick={() => setIsMobileMenuOpen(false)} />
              <NavItem to="/timovi" icon={<Users size={20}/>} label="Ekipe" onClick={() => setIsMobileMenuOpen(false)} />
              <NavItem to="/igraci" icon={<UserCircle size={20}/>} label="Igrači" onClick={() => setIsMobileMenuOpen(false)} />
              <NavItem to="/admin" icon={<Lock size={20}/>} label="Admin" onClick={() => setIsMobileMenuOpen(false)} />
            </ul>
            <div className="mt-8 flex flex-col gap-4">
               {currentUser ? (
                 <button onClick={handleLogout} className="w-full py-4 text-[10px] font-black uppercase tracking-widest bg-red-800 text-white sharp-border"><LogOut size={16} className="inline mr-2"/> Odjava</button>
               ) : (
                 <Link to="/login" onClick={() => setIsMobileMenuOpen(false)} className="w-full py-4 text-center text-[10px] font-black uppercase tracking-widest bg-[#00d4ff] text-[#010409] sharp-border"><LogIn size={16} className="inline mr-2"/> Prijava</Link>
               )}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-[#010409]">
          <div className="p-4 md:p-12 max-w-7xl mx-auto">
            <SubPageHeader />
            <Routes>
              <Route path="/" element={<Dashboard matches={matches} teams={teams} />} />
              <Route path="/raspored" element={<Schedule matches={matches} players={players} />} />
              <Route path="/tabela" element={<Standings teams={teams} />} />
              <Route path="/statistika" element={<Statistics matches={matches} players={players} />} />
              <Route path="/igraci" element={<Players players={players} />} />
              <Route path="/igraci/:playerId" element={<PlayerDetail players={players} matches={matches} />} />
              <Route path="/timovi" element={
                  <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {teams.map(t => (
                      <Link key={t.id} to={`/timovi/${encodeURIComponent(t.id)}`} className="bg-[#0d1117] border-4 border-[#010409] p-6 hover:bg-[#161b22] transition-all sharp-border flex flex-col items-center">
                        <div className="bg-[#010409] text-[#00d4ff] w-16 h-16 flex items-center justify-center font-black text-2xl sharp-border mb-4">{t.name.charAt(0)}</div>
                        <h3 className="text-sm font-black uppercase text-white">{t.name}</h3>
                      </Link>
                    ))}
                  </div>
                )}
              <Route path="/timovi/:teamId" element={<TeamDetail teams={teams} players={players} matches={matches} />} />
              <Route path="/login" element={<Login onLogin={(u) => { setCurrentUser(u); localStorage.setItem('kovin_league_user', JSON.stringify(u)); }} players={players} />} />
              <Route path="/admin" element={<Admin matches={matches} onUpdateMatch={handleUpdateMatch} players={players} onFullUpdate={(p, m) => { setBasePlayers(p); setMatches(m); handleUpdateCloud(m, p); }} isAdmin={currentUser?.role === 'admin'} />} />
              <Route path="/profil" element={currentUser?.role === 'player' ? <Profile user={currentUser} players={players} onUpdatePassword={(id, pass) => { const newP = basePlayers.map(p => p.id === id ? {...p, password: pass} : p); setBasePlayers(newP); handleUpdateCloud(matches, newP); }} /> : <Navigate to="/login" />} />
            </Routes>
          </div>
        </main>
      </div>
    </HashRouter>
  );
};

const NavItem: React.FC<{ to: string; icon: React.ReactNode; label: string; onClick: () => void }> = ({ to, icon, label, onClick }) => {
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <li>
      <Link to={to} onClick={onClick} className={`flex items-center gap-4 px-4 py-4 text-[10px] lg:text-sm font-black uppercase tracking-widest transition-all sharp-border ${isActive ? 'bg-[#161b22] text-white' : 'bg-[#0d1117] text-[#9ca3af] hover:bg-[#161b22]'}`}>
        <span className={isActive ? 'text-[#00d4ff]' : 'text-[#30363d]'}>{icon}</span>
        <span>{label}</span>
      </Link>
    </li>
  );
};

export default App;
