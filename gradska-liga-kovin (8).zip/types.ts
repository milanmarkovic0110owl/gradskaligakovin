
export interface Team {
  id: string;
  name: string;
  played: number;
  won: number;
  lost: number;
  matchesWon: number;
  matchesLost: number;
  setsWon: number;
  setsLost: number;
  points: number;
}

export interface SetResult {
  home: number;
  away: number;
}

export interface IndividualMatch {
  id: string;
  homePlayerId: string; // Povezano sa PlayerStats.id
  awayPlayerId: string; // Povezano sa PlayerStats.id
  sets: SetResult[]; 
  winner: 'home' | 'away' | null;
}

export interface TeamMatch {
  id: string;
  round: number;
  date: string;
  homeTeamId: string;
  awayTeamId: string;
  individualMatches: IndividualMatch[];
  isCompleted: boolean;
  scoreHome: number;
  scoreAway: number;
}

export type UserRole = 'admin' | 'player';

export interface User {
  id: string;
  username: string;
  password?: string;
  role: UserRole;
  playerId?: string;
}

export interface PlayerStats {
  id: string;
  name: string;
  teamId: string;
  imageUrl?: string;
  matchesPlayed: number;
  matchesWon: number;
  matchesLost: number;
  setsWon: number;
  setsLost: number;
  pointsWon: number;
  pointsLost: number;
  username: string;
  password?: string;
}
